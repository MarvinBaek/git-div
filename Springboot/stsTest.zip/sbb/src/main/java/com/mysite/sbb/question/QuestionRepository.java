package com.mysite.sbb.question;

import java.util.List;

import org.springframework.data.domain.Page; // 페이지네이션을 위한 Page 클래스
import org.springframework.data.domain.Pageable; // 페이지 요청 정보
import org.springframework.data.jpa.repository.JpaRepository; // 기본적인 JPA 기능 제공
import org.springframework.data.jpa.domain.Specification; // JPA 쿼리 조건을 정의할 수 있는 Specification 클래스
import org.springframework.data.jpa.repository.Query; // JPQL 쿼리 작성
import org.springframework.data.repository.query.Param; // 파라미터 바인딩

public interface QuestionRepository extends JpaRepository<Question, Integer> {
    
    // 제목으로 질문을 찾는 메서드
    Question findBySubject(String subject);
    
    // 제목과 내용으로 질문을 찾는 메서드
    Question findBySubjectAndContent(String subject, String content);
    
    // 제목이 주어진 문자열을 포함하는 질문 목록을 찾는 메서드
    List<Question> findBySubjectLike(String subject);
    
    // 페이지네이션을 적용하여 모든 질문을 가져오는 메서드
    Page<Question> findAll(Pageable pageable);
    
    // 조건을 만족하는 질문을 페이지네이션과 함께 가져오는 메서드
    Page<Question> findAll(Specification<Question> spec, Pageable pageable);
    
    // 검색 키워드를 통해 질문, 내용, 작성자, 답변 내용 등을 검색하는 JPQL 쿼리
    @Query("select "
            + "distinct q " // 중복 없이 질문을 가져옴
            + "from Question q " 
            + "left outer join SiteUser u1 on q.author=u1 " // 질문의 작성자 정보 가져오기
            + "left outer join Answer a on a.question=q " // 질문에 대한 답변 정보 가져오기
            + "left outer join SiteUser u2 on a.author=u2 " // 답변 작성자 정보 가져오기
            + "where "
            + "   q.subject like %:kw% " // 질문 제목에 검색어가 포함된 질문 찾기
            + "   or q.content like %:kw% " // 질문 내용에 검색어가 포함된 질문 찾기
            + "   or u1.username like %:kw% " // 질문 작성자의 사용자 이름에 검색어가 포함된 질문 찾기
            + "   or a.content like %:kw% " // 답변 내용에 검색어가 포함된 질문 찾기
            + "   or u2.username like %:kw% ") // 답변 작성자의 사용자 이름에 검색어가 포함된 질문 찾기
    Page<Question> findAllByKeyword(@Param("kw") String kw, Pageable pageable); // 검색어와 페이지 정보를 받아서 검색된 결과를 반환
}
