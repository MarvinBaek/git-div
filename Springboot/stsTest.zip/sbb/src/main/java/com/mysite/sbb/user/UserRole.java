package com.mysite.sbb.user;

import lombok.Getter;

// UserRole 열거형(enum) 클래스는 사용자의 역할을 정의합니다.
// ADMIN과 USER 역할을 정의하고 각각 "ROLE_ADMIN"과 "ROLE_USER"로 값을 설정합니다.
@Getter
public enum UserRole {

    // 관리자 역할
    ADMIN("ROLE_ADMIN"),

    // 일반 사용자 역할
    USER("ROLE_USER");

    // 열거형 상수에 대한 값 저장을 위한 필드
    private String value;

    // 생성자: 각 역할에 해당하는 값(value)을 초기화합니다.
    UserRole(String value) {
        this.value = value;
    }
}
