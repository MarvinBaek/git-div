package com.mysite.sbb.question;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import jakarta.validation.Valid;
import org.springframework.validation.BindingResult;
import com.mysite.sbb.answer.AnswerForm;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.data.domain.Page;
import java.security.Principal;
import com.mysite.sbb.user.SiteUser;
import com.mysite.sbb.user.UserService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import lombok.RequiredArgsConstructor;

@RequestMapping("/question") // "/question"으로 시작하는 요청을 처리하는 컨트롤러로 설정
@RequiredArgsConstructor // final 필드에 대해 생성자를 자동으로 생성
@Controller // Spring MVC의 컨트롤러로 정의
public class QuestionController {

	private final QuestionService questionService; // 질문 관련 서비스 객체
	private final UserService userService; // 사용자 관련 서비스 객체

    @GetMapping("/list") // 질문 목록 페이지 요청 처리
    public String list(Model model, @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "kw", defaultValue = "") String kw) {
        Page<Question> paging = this.questionService.getList(page, kw); // 질문 목록 페이징 처리
        model.addAttribute("paging", paging); // 페이징 데이터 모델에 추가
        model.addAttribute("kw", kw); // 검색 키워드 모델에 추가
        return "question_list"; // "question_list" 템플릿 반환
    }
	
	@GetMapping(value = "/detail/{id}") // 질문 상세 페이지 요청 처리
    public String detail(Model model, @PathVariable("id") Integer id, AnswerForm answerForm) {
        Question question = this.questionService.getQuestion(id); // ID로 질문 객체 가져오기
        model.addAttribute("question", question); // 질문 객체 모델에 추가
        return "question_detail"; // "question_detail" 템플릿 반환
    }
	
	@PreAuthorize("isAuthenticated()") // 인증된 사용자만 접근 가능
    @GetMapping("/create") // 질문 작성 페이지 요청 처리
    public String questionCreate(QuestionForm questionForm) {
        return "question_form"; // "question_form" 템플릿 반환
    }
	
	
	@PreAuthorize("isAuthenticated()") // 인증된 사용자만 접근 가능
    @PostMapping("/create") // 질문 작성 요청 처리
    public String questionCreate(@Valid QuestionForm questionForm, BindingResult bindingResult, Principal principal) {
        if (bindingResult.hasErrors()) { // 입력 값 검증 실패 시
            return "question_form"; // "question_form" 템플릿 반환
        }
        SiteUser siteUser = this.userService.getUser(principal.getName()); // 현재 사용자 가져오기
        this.questionService.create(questionForm.getSubject(), questionForm.getContent(), siteUser); // 질문 생성
        return "redirect:/question/list"; // 질문 목록 페이지로 리다이렉트
    }
	
    @PreAuthorize("isAuthenticated()") // 인증된 사용자만 접근 가능
    @GetMapping("/modify/{id}") // 질문 수정 페이지 요청 처리
    public String questionModify(QuestionForm questionForm, @PathVariable("id") Integer id, Principal principal) {
        Question question = this.questionService.getQuestion(id); // ID로 질문 객체 가져오기
        if(!question.getAuthor().getUsername().equals(principal.getName())) { // 작성자가 아닐 경우 예외 처리
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
        }
        questionForm.setSubject(question.getSubject()); // 질문 제목 설정
        questionForm.setContent(question.getContent()); // 질문 내용 설정
        return "question_form"; // "question_form" 템플릿 반환
    }
	
	
    @PreAuthorize("isAuthenticated()") // 인증된 사용자만 접근 가능
    @PostMapping("/modify/{id}") // 질문 수정 요청 처리
    public String questionModify(@Valid QuestionForm questionForm, BindingResult bindingResult, 
            Principal principal, @PathVariable("id") Integer id) {
        if (bindingResult.hasErrors()) { // 입력 값 검증 실패 시
            return "question_form"; // "question_form" 템플릿 반환
        }
        Question question = this.questionService.getQuestion(id); // ID로 질문 객체 가져오기
        if (!question.getAuthor().getUsername().equals(principal.getName())) { // 작성자가 아닐 경우 예외 처리
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
        }
        this.questionService.modify(question, questionForm.getSubject(), questionForm.getContent()); // 질문 수정
        return String.format("redirect:/question/detail/%s", id); // 질문 상세 페이지로 리다이렉트
    }
    
    @PreAuthorize("isAuthenticated()") // 인증된 사용자만 접근 가능
    @GetMapping("/delete/{id}") // 질문 삭제 요청 처리
    public String questionDelete(Principal principal, @PathVariable("id") Integer id) {
        Question question = this.questionService.getQuestion(id); // ID로 질문 객체 가져오기
        if (!question.getAuthor().getUsername().equals(principal.getName())) { // 작성자가 아닐 경우 예외 처리
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "삭제권한이 없습니다.");
        }
        this.questionService.delete(question); // 질문 삭제
        return "redirect:/"; // 메인 페이지로 리다이렉트
    }
    
    @PreAuthorize("isAuthenticated()") // 인증된 사용자만 접근 가능
    @GetMapping("/vote/{id}") // 질문 추천 요청 처리
    public String questionVote(Principal principal, @PathVariable("id") Integer id) {
        Question question = this.questionService.getQuestion(id); // ID로 질문 객체 가져오기
        SiteUser siteUser = this.userService.getUser(principal.getName()); // 현재 사용자 가져오기
        this.questionService.vote(question, siteUser); // 질문 추천
        return String.format("redirect:/question/detail/%s", id); // 질문 상세 페이지로 리다이렉트
    }
    
}
