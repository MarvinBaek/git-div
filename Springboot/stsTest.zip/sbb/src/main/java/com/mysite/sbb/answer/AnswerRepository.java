package com.mysite.sbb.answer;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AnswerRepository extends JpaRepository<Answer, Integer> {
    // Answer 엔터티에 대한 데이터베이스 접근을 제공하는 JPA 리포지토리 인터페이스
}
