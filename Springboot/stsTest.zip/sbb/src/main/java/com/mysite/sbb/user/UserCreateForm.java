package com.mysite.sbb.user;

import jakarta.validation.constraints.Email; // 이메일 유효성 검사를 위한 어노테이션
import jakarta.validation.constraints.NotEmpty; // 빈 값이 아닌지 확인하는 어노테이션
import jakarta.validation.constraints.Size; // 문자열 길이를 제한하는 어노테이션

import lombok.Getter; // Lombok을 이용해 getter 메서드 자동 생성
import lombok.Setter; // Lombok을 이용해 setter 메서드 자동 생성

@Getter
@Setter
public class UserCreateForm {

    // 사용자 ID에 대한 유효성 검사
    @Size(min = 3, max = 25) // 사용자 ID의 길이는 3자 이상 25자 이하
    @NotEmpty(message = "사용자ID는 필수항목입니다.") // 비어있지 않도록 필수 항목 설정
    private String username;

    // 비밀번호에 대한 유효성 검사
    @NotEmpty(message = "비밀번호는 필수항목입니다.") // 비밀번호가 비어있으면 안됨
    private String password1;

    // 비밀번호 확인에 대한 유효성 검사
    @NotEmpty(message = "비밀번호 확인은 필수항목입니다.") // 비밀번호 확인이 비어있으면 안됨
    private String password2;

    // 이메일에 대한 유효성 검사
    @NotEmpty(message = "이메일은 필수항목입니다.") // 이메일이 비어있으면 안됨
    @Email // 이메일 형식이 맞는지 검사
    private String email;
}
