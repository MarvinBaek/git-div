package com.mysite.sbb;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mysite.sbb.question.QuestionService;

@SpringBootTest
class SbbApplicationTests {

    // QuestionService를 주입받아 사용할 수 있게 설정
    @Autowired
    private QuestionService questionService;

    // JPA 관련 테스트 메서드
    @Test
    void testJpa() {
        // 1부터 300까지 반복하며 테스트 데이터를 생성
        for (int i = 1; i <= 300; i++) {
            // 주제는 "테스트 데이터입니다:[000]" 형태로 생성
            String subject = String.format("테스트 데이터입니다:[%03d]", i);
            // 내용은 "내용무"로 기본 설정
            String content = "내용무";
            // QuestionService를 사용하여 질문 데이터를 생성
            this.questionService.create(subject, content, null);
        }
    }
}
