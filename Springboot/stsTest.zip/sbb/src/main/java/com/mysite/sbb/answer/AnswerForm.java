package com.mysite.sbb.answer;

import jakarta.validation.constraints.NotEmpty; // 입력값 유효성 검사를 위한 애너테이션
import lombok.Getter; // Lombok을 이용해 getter 메서드를 자동 생성
import lombok.Setter; // Lombok을 이용해 setter 메서드를 자동 생성

@Getter // `content` 필드의 getter 메서드를 Lombok이 자동 생성
@Setter // `content` 필드의 setter 메서드를 Lombok이 자동 생성
public class AnswerForm { 
    // 답변 입력 데이터를 검증 및 전달하는 역할을 하는 폼 클래스
w
    @NotEmpty(message = "내용은 필수항목입니다.")
    // 유효성 검사 애너테이션: 해당 필드가 null이거나 빈 문자열이면 오류 발생
    // 오류 메시지는 "내용은 필수항목입니다."로 표시
    private String content; 
    // 답변 내용을 저장하는 필드
}
