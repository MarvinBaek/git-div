package com.mysite.sbb.answer;

import com.mysite.sbb.question.Question;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.mysite.sbb.user.SiteUser;
import java.util.Optional;
import com.mysite.sbb.DataNotFoundException;
import java.time.LocalDateTime;

@RequiredArgsConstructor // final 필드에 대한 생성자를 자동으로 생성
@Service // Spring의 서비스 클래스임을 나타내는 애너테이션
public class AnswerService {

    private final AnswerRepository answerRepository; 
    // 데이터베이스 작업을 위한 AnswerRepository 의존성 주입

    /**
     * 답변 생성 메서드
     * @param question 답변이 연결될 질문 객체
     * @param content 답변 내용
     * @param author 답변 작성자
     * @return 저장된 Answer 객체
     */
    public Answer create(Question question, String content, SiteUser author) {
        Answer answer = new Answer(); // 새로운 Answer 객체 생성
        answer.setContent(content); // 답변 내용 설정
        answer.setCreateDate(LocalDateTime.now()); // 생성 시간 설정
        answer.setQuestion(question); // 관련 질문 설정
        answer.setAuthor(author); // 작성자 설정
        this.answerRepository.save(answer); // 데이터베이스에 저장
        return answer; // 저장된 Answer 객체 반환
    }
    
    /**
     * 답변 조회 메서드
     * @param id 조회할 답변의 ID
     * @return 조회된 Answer 객체
     * @throws DataNotFoundException 답변이 없을 경우 예외 발생
     */
    public Answer getAnswer(Integer id) {
        Optional<Answer> answer = this.answerRepository.findById(id);
        if (answer.isPresent()) { // ID에 해당하는 답변이 존재하면 반환
            return answer.get();
        } else { // 없으면 예외 발생
            throw new DataNotFoundException("answer not found");
        }
    }

    /**
     * 답변 수정 메서드
     * @param answer 수정할 Answer 객체
     * @param content 새로 설정할 답변 내용
     */
    public void modify(Answer answer, String content) {
        answer.setContent(content); // 새로운 내용으로 설정
        answer.setModifyDate(LocalDateTime.now()); // 수정 시간 업데이트
        this.answerRepository.save(answer); // 데이터베이스에 저장
    }

    /**
     * 답변 삭제 메서드
     * @param answer 삭제할 Answer 객체
     */
    public void delete(Answer answer) {
        this.answerRepository.delete(answer); // 데이터베이스에서 삭제
    }
    
    /**
     * 답변 추천(vote) 메서드
     * @param answer 추천할 답변 객체
     * @param siteUser 추천한 사용자
     */
    public void vote(Answer answer, SiteUser siteUser) {
        answer.getVoter().add(siteUser); // 추천 사용자 추가
        this.answerRepository.save(answer); // 업데이트된 Answer 객체 저장
    }
}
