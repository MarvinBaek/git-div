package com.mysite.sbb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// @SpringBootApplication 어노테이션은 Spring Boot 애플리케이션의 진입점을 나타냅니다.
// 이 어노테이션은 @Configuration, @EnableAutoConfiguration, @ComponentScan을 합친 역할을 합니다.
// 즉, Spring Boot 애플리케이션을 설정하고 자동으로 필요한 설정을 로드하며,
// 기본적으로 애플리케이션이 위치한 패키지와 하위 패키지에서 컴포넌트를 자동으로 스캔합니다.
@SpringBootApplication
public class SbbApplication {

    // main 메서드는 Spring Boot 애플리케이션을 시작하는 진입점입니다.
    public static void main(String[] args) {
        // SpringApplication.run()은 Spring Boot 애플리케이션을 실행하는 메서드입니다.
        // SbbApplication.class를 인자로 전달하면, Spring Boot 애플리케이션이 실행됩니다.
        SpringApplication.run(SbbApplication.class, args);
    }
}
