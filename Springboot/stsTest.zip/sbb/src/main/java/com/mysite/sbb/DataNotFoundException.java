package com.mysite.sbb;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

// DataNotFoundException은 Spring의 @ResponseStatus 어노테이션을 활용하여 
// HTTP 상태 코드 404 (Not Found)와 함께 발생한 예외에 대한 사용자 정의 메시지를 전달하는 예외 클래스입니다.
@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "entity not found")  // 404 상태 코드 및 'entity not found' 메시지 반환
public class DataNotFoundException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    // 생성자에서 예외 메시지를 전달받고 부모 클래스인 RuntimeException의 생성자를 호출하여 초기화
    public DataNotFoundException(String message) {
        super(message);
    }
}
