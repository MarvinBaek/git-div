package com.mysite.sbb.user;

import jakarta.validation.Valid; // 유효성 검사를 위한 어노테이션
import org.springframework.stereotype.Controller; // 이 클래스가 Spring MVC의 Controller 역할을 함을 나타냄
import org.springframework.validation.BindingResult; // 유효성 검사 후 결과를 담는 객체
import org.springframework.web.bind.annotation.GetMapping; // GET 요청을 처리하는 메서드 지정
import org.springframework.web.bind.annotation.PostMapping; // POST 요청을 처리하는 메서드 지정
import org.springframework.web.bind.annotation.RequestMapping; // 클래스에서 공통된 URL 패턴을 설정
import org.springframework.dao.DataIntegrityViolationException; // 데이터베이스 제약 조건 위반 예외 처리

import lombok.RequiredArgsConstructor; // Lombok 어노테이션, 생성자 주입을 위한 어노테이션

@RequiredArgsConstructor // final 필드에 대해 생성자를 자동으로 생성
@Controller // 해당 클래스가 Spring MVC의 Controller임을 지정
@RequestMapping("/user") // 모든 요청 경로에 "/user"를 공통적으로 붙이도록 설정
public class UserController {

    private final UserService userService; // UserService를 의존성 주입 받음

    // 사용자 회원가입 폼을 보여주는 GET 요청 처리
    @GetMapping("/signup")
    public String signup(UserCreateForm userCreateForm) {
        return "signup_form"; // signup_form 뷰로 이동
    }

    // 사용자 로그인 폼을 보여주는 GET 요청 처리
    @GetMapping("/login")
    public String login() {
        return "login_form"; // login_form 뷰로 이동
    }

    // 사용자 회원가입 처리하는 POST 요청 처리
    @PostMapping("/signup")
    public String signup(@Valid UserCreateForm userCreateForm, BindingResult bindingResult) {
        // 폼 데이터 유효성 검사
        if (bindingResult.hasErrors()) {
            return "signup_form"; // 에러가 있으면 signup_form 뷰로 돌아감
        }

        // 비밀번호 확인
        if (!userCreateForm.getPassword1().equals(userCreateForm.getPassword2())) {
            bindingResult.rejectValue("password2", "passwordInCorrect", 
                    "2개의 패스워드가 일치하지 않습니다."); // 비밀번호 불일치 오류
            return "signup_form"; // 에러가 있으면 signup_form 뷰로 돌아감
        }

        // 회원가입 처리
        try {
            userService.create(userCreateForm.getUsername(), 
                    userCreateForm.getEmail(), userCreateForm.getPassword1());
        } catch(DataIntegrityViolationException e) {
            e.printStackTrace();
            bindingResult.reject("signupFailed", "이미 등록된 사용자입니다."); // 데이터베이스 제약 위반 시 처리
            return "signup_form"; // 에러가 있으면 signup_form 뷰로 돌아감
        } catch(Exception e) {
            e.printStackTrace();
            bindingResult.reject("signupFailed", e.getMessage()); // 기타 예외 처리
            return "signup_form"; // 에러가 있으면 signup_form 뷰로 돌아감
        }

        // 회원가입 성공 시 메인 페이지로 리다이렉트
        return "redirect:/";
    }
}
