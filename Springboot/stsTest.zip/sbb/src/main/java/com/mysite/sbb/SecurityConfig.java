package com.mysite.sbb;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.header.writers.frameoptions.XFrameOptionsHeaderWriter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;

@Configuration  // Spring의 설정 클래스를 나타냅니다.
@EnableWebSecurity  // 웹 보안을 활성화하여 Spring Security 기능을 설정합니다.
@EnableMethodSecurity(prePostEnabled = true)  // 메서드 보안을 활성화합니다. @PreAuthorize, @PostAuthorize와 같은 어노테이션을 사용할 수 있습니다.
public class SecurityConfig {

    // HTTP 보안 설정을 위한 Bean을 정의합니다.
    @Bean
    SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests((authorizeHttpRequests) -> authorizeHttpRequests
                .requestMatchers(new AntPathRequestMatcher("/**")).permitAll())  // 모든 요청에 대해 접근을 허용합니다.
            .csrf((csrf) -> csrf
                    .ignoringRequestMatchers(new AntPathRequestMatcher("/h2-console/**")))  // H2 콘솔 URL에 대해 CSRF를 무시합니다.
            .headers((headers) -> headers
                    .addHeaderWriter(new XFrameOptionsHeaderWriter(
                        XFrameOptionsHeaderWriter.XFrameOptionsMode.SAMEORIGIN)))  // X-Frame-Options를 SAMEORIGIN으로 설정하여 클릭재킹 방지
            .formLogin((formLogin) -> formLogin
                    .loginPage("/user/login")  // 로그인 페이지 URL을 설정합니다.
                    .defaultSuccessUrl("/"))  // 로그인 성공 시 이동할 기본 URL을 설정합니다.
            .logout((logout) -> logout
                    .logoutRequestMatcher(new AntPathRequestMatcher("/user/logout"))  // 로그아웃 요청 URL 설정
                    .logoutSuccessUrl("/")  // 로그아웃 성공 후 이동할 URL 설정
                    .invalidateHttpSession(true))  // 로그아웃 시 세션 무효화
        ;
        return http.build();  // 설정을 기반으로 SecurityFilterChain을 반환합니다.
    }

    // 패스워드 인코더로 BCryptPasswordEncoder를 설정합니다.
    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();  // BCrypt 알고리즘을 사용하여 비밀번호를 암호화합니다.
    }

    // AuthenticationManager를 Bean으로 정의하여 Spring Security의 인증 처리에 사용합니다.
    @Bean
    AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();  // AuthenticationConfiguration을 통해 AuthenticationManager를 반환합니다.
    }
}
