package com.mysite.sbb.user;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

// UserRepository는 JpaRepository를 상속받아 SiteUser 엔티티에 대한 CRUD 작업을 지원
public interface UserRepository extends JpaRepository<SiteUser, Long> {

    // 사용자 이름(username)을 기준으로 SiteUser 객체를 찾아서 반환
    // 반환 타입은 Optional로, 사용자 정보가 없을 경우 빈 Optional을 반환
    Optional<SiteUser> findByusername(String username);
}
