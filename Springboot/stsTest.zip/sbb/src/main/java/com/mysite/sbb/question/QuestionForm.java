package com.mysite.sbb.question;

import jakarta.validation.constraints.NotEmpty; // 입력 값 검증을 위한 필드 제약 조건
import jakarta.validation.constraints.Size; // 문자열 길이 제약 조건

import lombok.Getter; // Lombok의 Getter 자동 생성
import lombok.Setter; // Lombok의 Setter 자동 생성

@Getter // 모든 필드에 대한 Getter 메서드 자동 생성
@Setter // 모든 필드에 대한 Setter 메서드 자동 생성
public class QuestionForm {
    
    @NotEmpty(message="제목은 필수항목입니다.") // 제목이 비어 있으면 안 되며, 오류 메시지 설정
    @Size(max=200) // 제목의 최대 길이를 200자로 제한
    private String subject; // 질문 제목

    @NotEmpty(message="내용은 필수항목입니다.") // 내용이 비어 있으면 안 되며, 오류 메시지 설정
    private String content; // 질문 내용
}
