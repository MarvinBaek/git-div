package com.mysite.sbb.user;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.Optional;
import com.mysite.sbb.DataNotFoundException;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class UserService {

    // 사용자 정보는 UserRepository에서 처리하고, 비밀번호는 PasswordEncoder로 암호화
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    // 사용자 생성 메서드
    public SiteUser create(String username, String email, String password) {
        // 새로운 SiteUser 객체 생성
        SiteUser user = new SiteUser();
        user.setUsername(username);   // 사용자 이름 설정
        user.setEmail(email);         // 이메일 설정
        user.setPassword(passwordEncoder.encode(password));  // 비밀번호 암호화 후 설정

        // 사용자 정보를 DB에 저장
        this.userRepository.save(user);
        
        // 저장한 사용자 반환
        return user;
    }
    
    // 사용자 이름을 기반으로 SiteUser 객체를 조회하는 메서드
    public SiteUser getUser(String username) {
        // 사용자 이름으로 SiteUser를 조회
        Optional<SiteUser> siteUser = this.userRepository.findByusername(username);
        
        // 사용자가 존재하면 반환, 그렇지 않으면 예외 발생
        if (siteUser.isPresent()) {
            return siteUser.get();
        } else {
            throw new DataNotFoundException("siteuser not found");  // 사용자가 존재하지 않으면 예외
        }
    }
}
