package com.mysite.sbb.user;

import jakarta.persistence.Column; // JPA 어노테이션, 데이터베이스 컬럼과 매핑
import jakarta.persistence.Entity; // JPA 어노테이션, 해당 클래스가 엔티티임을 표시
import jakarta.persistence.GeneratedValue; // JPA 어노테이션, ID 생성 방식을 지정
import jakarta.persistence.GenerationType; // ID 생성 방식의 종류 (예: AUTO, IDENTITY 등)
import jakarta.persistence.Id; // JPA 어노테이션, 해당 필드가 기본 키임을 지정

import lombok.Getter; // Lombok 어노테이션, getter 메서드를 자동 생성
import lombok.Setter; // Lombok 어노테이션, setter 메서드를 자동 생성

@Getter // Lombok 어노테이션, 모든 필드에 대해 getter 메서드를 생성
@Setter // Lombok 어노테이션, 모든 필드에 대해 setter 메서드를 생성
@Entity // 해당 클래스가 JPA 엔티티로 매핑됨을 나타냄
public class SiteUser {

    @Id // 이 필드는 엔티티의 기본 키로 사용
    @GeneratedValue(strategy = GenerationType.IDENTITY) // 기본 키를 데이터베이스에서 자동 생성
    private Long id; // 사용자 ID

    @Column(unique = true) // 데이터베이스에서 해당 컬럼이 유니크하도록 설정
    private String username; // 사용자 이름

    private String password; // 사용자 비밀번호

    @Column(unique = true) // 데이터베이스에서 해당 컬럼이 유니크하도록 설정
    private String email; // 사용자 이메일
}
