package com.mysite.sbb.question;

import java.time.LocalDateTime; // 날짜와 시간을 저장하는 클래스
import java.util.List; // 답변 목록을 저장하기 위한 리스트
import java.util.Set; // 추천한 사용자 목록을 저장하기 위한 집합(Set)

import com.mysite.sbb.answer.Answer; // Answer 엔터티와의 관계를 위해 import
import jakarta.persistence.*; // JPA 관련 애너테이션들 import
import com.mysite.sbb.user.SiteUser; // SiteUser 엔터티와의 관계를 위해 import

import lombok.Getter; // Lombok을 이용해 getter 메서드 자동 생성
import lombok.Setter; // Lombok을 이용해 setter 메서드 자동 생성

@Getter // 모든 필드에 대한 getter 메서드를 Lombok이 자동 생성
@Setter // 모든 필드에 대한 setter 메서드를 Lombok이 자동 생성
@Entity // 이 클래스가 JPA 엔터티임을 나타냄
public class Question {

    private LocalDateTime modifyDate; 
    // 질문 수정 날짜 및 시간을 저장

    @Id // 기본 키를 나타냄
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    // ID 값을 자동 생성 (Primary Key, Auto Increment)
    private Integer id; 

    @Column(length = 200) 
    // 제목 컬럼, 최대 길이는 200자로 제한
    private String subject; 

    @Column(columnDefinition = "TEXT") 
    // 내용 컬럼, TEXT 타입으로 저장 (큰 데이터 허용)
    private String content; 

    private LocalDateTime createDate; 
    // 질문 생성 날짜 및 시간을 저장

    @OneToMany(mappedBy = "question", cascade = CascadeType.REMOVE) 
    // Answer와 1:N 관계를 설정
    // 질문이 삭제되면 연결된 답변도 삭제 (`cascade = CascadeType.REMOVE`)
    private List<Answer> answerList; 
    // 이 질문에 달린 답변 목록을 저장

    @ManyToOne 
    // 여러 질문이 하나의 작성자(SiteUser)와 연결될 수 있음
    private SiteUser author; 
    // 질문 작성자를 나타냄

    @ManyToMany 
    // 여러 사용자가 이 질문을 추천할 수 있음
    private Set<SiteUser> voter; 
    // 추천한 사용자 목록을 저장
}
