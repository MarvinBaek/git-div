package com.mysite.sbb.question;

import java.util.List;

import org.springframework.stereotype.Service;
import java.util.Optional;
import com.mysite.sbb.DataNotFoundException;
import java.time.LocalDateTime;
import org.springframework.data.domain.Page; // Page 객체는 페이징 처리된 데이터를 다룸
import org.springframework.data.domain.PageRequest; // PageRequest는 페이징 정보 생성에 사용
import org.springframework.data.domain.Pageable; // Pageable은 페이지와 정렬 정보를 다룸
import java.util.ArrayList; // ArrayList를 사용하여 정렬 조건을 추가
import org.springframework.data.domain.Sort; // Sort는 정렬 방식 설정을 위한 클래스
import com.mysite.sbb.user.SiteUser; // SiteUser는 질문과 답변 작성자 정보를 처리
import com.mysite.sbb.answer.Answer; // Answer 객체는 질문에 대한 답변을 처리
import jakarta.persistence.criteria.CriteriaBuilder; // CriteriaBuilder는 JPA Criteria API에서 쿼리 조건을 정의하는 데 사용
import jakarta.persistence.criteria.CriteriaQuery; // CriteriaQuery는 JPA Criteria API에서 반환할 결과를 정의
import jakarta.persistence.criteria.Join; // Join은 JPA에서 테이블 간의 조인을 처리
import jakarta.persistence.criteria.JoinType; // JoinType은 LEFT, RIGHT, INNER 등 조인 방식을 정의
import jakarta.persistence.criteria.Predicate; // Predicate는 쿼리의 조건을 정의
import jakarta.persistence.criteria.Root; // Root는 JPA Criteria API에서 쿼리의 기준이 되는 엔티티를 정의
import org.springframework.data.jpa.domain.Specification; // Specification은 동적 쿼리를 작성하는 데 사용

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class QuestionService {

    private final QuestionRepository questionRepository; // 질문을 DB에서 처리하는 리포지토리
    
    // 검색 조건을 기준으로 동적 쿼리를 작성하는 메서드
    private Specification<Question> search(String kw) {
        return new Specification<>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Predicate toPredicate(Root<Question> q, CriteriaQuery<?> query, CriteriaBuilder cb) {
                query.distinct(true);  // 중복 제거를 위한 distinct 설정
                Join<Question, SiteUser> u1 = q.join("author", JoinType.LEFT); // 질문 작성자와의 조인
                Join<Question, Answer> a = q.join("answerList", JoinType.LEFT); // 질문에 대한 답변 목록과의 조인
                Join<Answer, SiteUser> u2 = a.join("author", JoinType.LEFT); // 답변 작성자와의 조인
                
                // 검색어가 제목, 내용, 질문 작성자, 답변 내용, 답변 작성자에 포함되었을 때 결과로 반환
                return cb.or(
                        cb.like(q.get("subject"), "%" + kw + "%"), // 제목에서 검색어 찾기
                        cb.like(q.get("content"), "%" + kw + "%"), // 내용에서 검색어 찾기
                        cb.like(u1.get("username"), "%" + kw + "%"), // 질문 작성자에서 검색어 찾기
                        cb.like(a.get("content"), "%" + kw + "%"), // 답변 내용에서 검색어 찾기
                        cb.like(u2.get("username"), "%" + kw + "%")  // 답변 작성자에서 검색어 찾기
                );
            }
        };
    }

    // 모든 질문을 반환하는 메서드
    public List<Question> getList() {
        return this.questionRepository.findAll(); // 리포지토리에서 모든 질문을 가져옴
    }
    
    // 질문 ID로 질문을 가져오는 메서드
    public Question getQuestion(Integer id) {  
        Optional<Question> question = this.questionRepository.findById(id); // ID로 질문 찾기
        if (question.isPresent()) {
            return question.get(); // 존재하면 반환
        } else {
            throw new DataNotFoundException("question not found"); // 없으면 예외 던짐
        }
    }
    
    // 새로운 질문을 생성하는 메서드
    public void create(String subject, String content, SiteUser user) {
        Question q = new Question();
        q.setSubject(subject); // 제목 설정
        q.setContent(content); // 내용 설정
        q.setCreateDate(LocalDateTime.now()); // 생성일자 설정
        q.setAuthor(user); // 작성자 설정
        this.questionRepository.save(q); // 리포지토리에 저장
    }
    
    // 페이지네이션을 적용하여 질문 목록을 반환하는 메서드
    public Page<Question> getList(int page, String kw) {
        List<Sort.Order> sorts = new ArrayList<>(); // 정렬 조건을 저장할 리스트
        sorts.add(Sort.Order.desc("createDate")); // 생성일 기준 내림차순 정렬
        Pageable pageable = PageRequest.of(page, 10, Sort.by(sorts)); // 페이지 요청 정보 생성
        return this.questionRepository.findAllByKeyword(kw, pageable); // 검색어와 페이지 정보에 맞는 결과 반환
    }
    
    // 질문을 수정하는 메서드
    public void modify(Question question, String subject, String content) {
        question.setSubject(subject); // 제목 수정
        question.setContent(content); // 내용 수정
        question.setModifyDate(LocalDateTime.now()); // 수정일자 설정
        this.questionRepository.save(question); // 수정된 질문을 저장
    }
    
    // 질문을 삭제하는 메서드
    public void delete(Question question) {
        this.questionRepository.delete(question); // 리포지토리에서 삭제
    }
    
    // 질문에 투표하는 메서드
    public void vote(Question question, SiteUser siteUser) {
        question.getVoter().add(siteUser); // 질문에 투표한 사용자 추가
        this.questionRepository.save(question); // 변경된 질문 저장
    }
}
