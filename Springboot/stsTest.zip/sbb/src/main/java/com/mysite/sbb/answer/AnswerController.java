package com.mysite.sbb.answer;

import com.mysite.sbb.question.Question;
import com.mysite.sbb.question.QuestionService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import jakarta.validation.Valid;
import org.springframework.validation.BindingResult;
import java.security.Principal;
import com.mysite.sbb.user.SiteUser;
import com.mysite.sbb.user.UserService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.server.ResponseStatusException;

@RequestMapping("/answer") // URL 시작 경로를 "/answer"로 설정
@RequiredArgsConstructor // Lombok 애너테이션: final로 선언된 필드를 자동으로 생성자 주입
@Controller // Spring MVC 컨트롤러로 선언
public class AnswerController {

	private final QuestionService questionService; // 질문 관련 서비스
	private final AnswerService answerService; // 답변 관련 서비스
	private final UserService userService; // 사용자 관련 서비스

	// 답변 생성 (로그인한 사용자만 가능)
	@PreAuthorize("isAuthenticated()") // 로그인 상태 확인
	@PostMapping("/create/{id}") // POST 요청을 처리, URL에 질문 ID 포함
	public String createAnswer(Model model, @PathVariable("id") Integer id, @Valid AnswerForm answerForm,
			BindingResult bindingResult, Principal principal) {
		Question question = this.questionService.getQuestion(id); // ID로 질문 가져오기
		SiteUser siteUser = this.userService.getUser(principal.getName()); // 현재 로그인한 사용자 정보 가져오기
		if (bindingResult.hasErrors()) { // 유효성 검사 실패 시
			model.addAttribute("question", question); // 질문 데이터 전달
			return "question_detail"; // 질문 상세 페이지로 돌아감
		}
		Answer answer = this.answerService.create(question, answerForm.getContent(), siteUser); // 답변 생성
		return String.format("redirect:/question/detail/%s#answer_%s", answer.getQuestion().getId(), answer.getId()); // 답변
																														// 생성
																														// 후
																														// 질문
																														// 상세
																														// 페이지로
																														// 리다이렉트
	}

	// 답변 수정 처리 (로그인한 사용자만 가능)
	@PreAuthorize("isAuthenticated()")
	@PostMapping("/modify/{id}")
	public String answerModify(@Valid AnswerForm answerForm, BindingResult bindingResult,
			@PathVariable("id") Integer id, Principal principal) {
		if (bindingResult.hasErrors()) { // 유효성 검사 실패 시
			return "answer_form"; // 수정 폼으로 돌아감
		}
		Answer answer = this.answerService.getAnswer(id); // ID로 답변 가져오기
		if (!answer.getAuthor().getUsername().equals(principal.getName())) {
			// 작성자가 현재 사용자와 다르면 예외 발생
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
		}
		this.answerService.modify(answer, answerForm.getContent()); // 답변 수정
		return String.format("redirect:/question/detail/%s#answer_%s", answer.getQuestion().getId(), answer.getId()); // 수정
																														// 후
																														// 질문
																														// 상세
																														// 페이지로
																														// 리다이렉트
	}

	// 답변 수정 폼 표시
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/modify/{id}")
	public String answerModify(AnswerForm answerForm, @PathVariable("id") Integer id, Principal principal) {
		Answer answer = this.answerService.getAnswer(id); // ID로 답변 가져오기
		if (!answer.getAuthor().getUsername().equals(principal.getName())) {
			// 작성자가 현재 사용자와 다르면 예외 발생
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "수정권한이 없습니다.");
		}
		answerForm.setContent(answer.getContent()); // 기존 답변 내용을 폼에 설정
		return "answer_form"; // 답변 수정 폼으로 이동
	}

	// 답변 삭제 (로그인한 사용자만 가능)
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/delete/{id}")
	public String answerDelete(Principal principal, @PathVariable("id") Integer id) {
		Answer answer = this.answerService.getAnswer(id); // ID로 답변 가져오기
		if (!answer.getAuthor().getUsername().equals(principal.getName())) {
			// 작성자가 현재 사용자와 다르면 예외 발생
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "삭제권한이 없습니다.");
		}
		this.answerService.delete(answer); // 답변 삭제
		return String.format("redirect:/question/detail/%s", answer.getQuestion().getId());
		// 삭제 후 질문 상세 페이지로 리다이렉트
	}

	// 답변 추천 (로그인한 사용자만 가능)
	@PreAuthorize("isAuthenticated()")
	@GetMapping("/vote/{id}")
	public String answerVote(Principal principal, @PathVariable("id") Integer id) {
		Answer answer = this.answerService.getAnswer(id); // ID로 답변 가져오기
		SiteUser siteUser = this.userService.getUser(principal.getName()); // 현재 사용자 정보 가져오기
		this.answerService.vote(answer, siteUser); // 추천 처리
		return String.format("redirect:/question/detail/%s#answer_%s", answer.getQuestion().getId(), answer.getId()); // 추천
																														// 후
																														// 질문
																														// 상세
																														// 페이지로
																														// 리다이렉트
	}
}
