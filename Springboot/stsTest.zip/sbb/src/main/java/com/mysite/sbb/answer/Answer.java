package com.mysite.sbb.answer;

// 필요한 클래스 및 패키지를 임포트합니다.
import java.time.LocalDateTime; // 날짜와 시간을 다루는 클래스
import com.mysite.sbb.question.Question; // Question 엔티티를 참조
import jakarta.persistence.*; // JPA 관련 애너테이션들
import com.mysite.sbb.user.SiteUser; // 사용자 엔티티 참조
import java.util.Set; // 컬렉션 인터페이스
import lombok.Getter; // Lombok 라이브러리로 Getter 메서드 자동 생성
import lombok.Setter; // Lombok 라이브러리로 Setter 메서드 자동 생성

@Getter // Lombok 애너테이션으로 getter 메서드를 자동 생성
@Setter // Lombok 애너테이션으로 setter 메서드를 자동 생성
@Entity // 이 클래스가 JPA 엔티티임을 나타냄
public class Answer { // "Answer" 테이블에 해당하는 엔티티 클래스

    private LocalDateTime modifyDate; 
    // 답변이 수정된 시간을 저장합니다. 수정되지 않았다면 null일 수 있습니다.

    @Id // 이 필드가 기본 키(primary key)임을 나타냅니다.
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    // 기본 키 값을 자동으로 생성하며, IDENTITY 전략은 데이터베이스가 키 생성을 관리하도록 설정합니다.
    private Integer id; // 답변의 고유 ID

    @Column(columnDefinition = "TEXT") 
    // 데이터베이스에서 해당 필드를 TEXT 타입으로 지정합니다.
    private String content; 
    // 답변 내용을 저장하는 필드입니다.

    private LocalDateTime createDate; 
    // 답변이 생성된 시간을 저장합니다.

    @ManyToOne 
    // N:1 관계를 정의합니다. 여러 개의 답변이 하나의 질문(Question)과 연결될 수 있습니다.
    private Question question; 
    // 이 답변이 속한 질문을 나타냅니다.

    @ManyToOne
    // N:1 관계를 정의합니다. 여러 개의 답변이 하나의 작성자(SiteUser)와 연결될 수 있습니다.
    private SiteUser author; 
    // 답변을 작성한 사용자입니다.

    @ManyToMany
    // N:M 관계를 정의합니다. 여러 사용자가 답변에 투표할 수 있고, 하나의 사용자가 여러 답변에 투표할 수 있습니다.
    Set<SiteUser> voter; 
    // 이 답변을 추천한 사용자들의 집합(Set)을 저장합니다.
}
